/* Name: Nabeel Majid(C3287060)
 * Seng2200-Assignment2
 * Date 20/04/23
description: abstract planarShape class with 3 abstract method and one concreate method its a parent class for 
Circle,Polygon and Semicircle. 
*/
import java.util.Iterator;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

public class A2 {

	public static void main(String[] args) throws FileNotFoundException{
		
		// TODO Auto-generated method stub
		 LinkedList<PlanarShape> unsortedlist = new LinkedList<PlanarShape>();
		SortedLinkedList<PlanarShape> sortedlist = new SortedLinkedList<PlanarShape>();
		
		//reading from a file
		Scanner  inputStream = new Scanner(new File(args[0]));
		
		 while (inputStream.hasNext())//until the last element 
		 {
			 //check first word for the shape and storing it in the word.and passing it to the shapefactory method
			 //along with Scanner to produce a shape and creating an Instance of Planarshape and storing our produce
			 //shape in that instance.
			 
			 char word= inputStream.next().charAt(0);
			 PlanarShape shape; 
			 shape=shapeFactory(word,inputStream);
			 unsortedlist.append(shape);
			
		
		 }
		 //created three iterator  1.iter for tranverse through unsorted list  2.iter1 for sorting the list
		 //3. iter2 for tranversing sortedlist.
		 System.out.print("unsorted list"+"\n");
		 Iterator<PlanarShape> iter= unsortedlist.iterator();
		 while(iter.hasNext())
		 {
			 System.out.print(iter.next().toString()+"\n");
		 }
		 Iterator<PlanarShape> iter1= unsortedlist.iterator();
		 while(iter1.hasNext())
		 {
			
			 sortedlist.InsertinOrder(iter1.next());
			  
		 }
		 System.out.print("sorted list"+"\n");
		 Iterator<PlanarShape> iter2= sortedlist.iterator();
		 while(iter2.hasNext())
		 {
			 //System.out.print("loop is working\n");
			 //String str;
			 //str += iter.next().toString();
			 
			 System.out.print(iter2.next().toString()+"\n");
			 
		 }
		 
	}
//Shape factory method takes a character and a scanner to create a planarShape
	private static PlanarShape shapeFactory(char t, Scanner sc)
	{
		PlanarShape shape = null;
		//creating Polygon shape
		if(t=='P')
		{
			//shape=new Polygon();
			int n = sc.nextInt();//to get the size of Polygon
            Point[] points = new Point[n];
           for(int i=0;i<n;i++)//initializing point and storing it in point array
           {
        	   points[i]=new Point();
        	   points[i].set_X(sc.nextDouble());
               points[i].set_Y(sc.nextDouble());		
              
           }
           
       shape= new Polygon(points);//Polygon with point type 
        //polygon.area();//Calculating area of polygon
			
		}
		else
			if(t=='C')//to create a new Circle shape
		{
		//	shape=new Circle();
		double[] arr = new double[3];
		for (int i=0;i<3;i++)
		{
			arr[i]=sc.nextDouble();
		}
		shape=new Circle(arr);
		}
		//creating a semiCircle shape
		else 
			if(t=='S')
		{
			//shape=new SemiCircle();
			double[] arr = new double[4];
			for (int i=0;i<4;i++)
			{
				arr[i]=sc.nextDouble();
			}
			shape=new SemiCircle(arr);
		}
		
		return shape;
	}
	
}


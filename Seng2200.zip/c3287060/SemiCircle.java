/* Name: Nabeel Majid(C3287060)
 * Seng2200-Assignment2
 * Date 20/04/23
description: It is child class for Planarshape and construct SemiCircle shape for PlanarShape
*/
public class SemiCircle extends PlanarShape {

	private Point[] points;
//default constructor
	public SemiCircle()
	{
		points=null;
		
	}
	//constructor with double array as parameter
	public SemiCircle(double[] arr)
	{
		
		points = new Point[arr.length];
		points[0]=new Point(arr[0],arr[1]); //centre of semicircle
		points[1]= new Point(arr[2],arr[3]);//perpendicular
		//left of semicircle
		points[2]= new Point(points[0].get_X()- Math.abs(points[0].get_Y()-points[1].get_Y() ),points[0].get_Y()+Math.abs(points[0].get_X()-points[1].get_Y() ));
		//right of semicircle
		points[3]= new Point(points[0].get_X()+ Math.abs(points[0].get_Y()-points[1].get_Y() ),points[0].get_Y()-Math.abs(points[0].get_X()-points[1].get_Y() ));					
		
	}
	//Method to print Semicircle
	@Override
	public String toString() {
		    
		return "SEMI=[" + points[0].toString()+ points[1].toString()+" ]: "  +  String.format("%5.2f" , this.area());
	}
//method to calculate and return area of SemiCircle
	@Override
	public double area() {
			
	return  Math.PI* Math.pow(this.SCradius(), 2)/2;
	
	}
	//Method Calculate the Radius of SemiCircle
	private double SCradius() {
		
		return Math.sqrt(Math.pow(points[1].get_X()-points[0].get_X(), 2) + Math.pow(points[1].get_Y()-points[0].get_Y(), 2));
	}
	//method to find distance of origin and return it.
	@Override
	public double distance_from_origin() {
		double distance;
		distance= points[0].get_distance();
		if(points[1].get_distance()<distance)
		{
			distance=points[1].get_distance(); 
		}
		if(points[2].get_distance()<distance)
		{
			distance=points[2].get_distance(); 
		}
		if(points[3].get_distance()<distance)
		{
			distance=points[3].get_distance(); 
		}
		return distance;
	}
}

import java.lang.Math;
public class Polygon implements ComparePoly{//Polygon class implement Comesbefore method
	private Point [] vertices ;
	private  double area;
	private double origin;
	//polygon default construct
	public Polygon()
	{
		area = 0;
		origin= 0;
		vertices=null; 
		
	}
	//polygon constructor with Point array
	public Polygon(Point[] p)
	{
		
		vertices = new Point[p.length];
		for(int i=0; i<p.length;i++)
		{
			vertices[i]=new Point();
			vertices[i]=p[i];
			vertices[i].distance_from_origin();
		}
	
		
	}
	//method to find the nearest point from origin by comparing all the point in the polygon and storing it in origin
	public double distance_from_origin()
	{
		origin= vertices[0].get_distance();
		for(int i=1; i<vertices.length;i++)
		{
			if(origin>vertices[i].get_distance())
			{
				origin=vertices[i].get_distance();
			}
		}
		return origin;
	}
	//Method to convert Polygon into string of format 6.2
	public String toString()
    {
                
        String str = "[";
        if(vertices != null)
        {
            for(int x = 0; x < vertices.length; x++)
            {
                str += "("+vertices[x].toString()+") ";               
            }
        }
        else{
            str = null;
        }
        
        return str+"]:   "+String.format("%6.2f" , area);
    }
	// this method calculate the product of P1 and Point two to find area
	 public double c_prod(Point p1, Point p2)
	   {
	       return (p1.get_X() * p2.get_Y())-(p1.get_Y()*p2.get_X());
	    }
	   //method to calculate area of Polygon 
	    public void Cal_area(int n)
	    {
	      
	    	double sum=0;
	        for(int i=0;i<n-1;i++)
	        {
	        sum+=c_prod(this.vertices[i],this.vertices[i+1]);
	        
	        }
	        sum+=c_prod(this.vertices[n-1],this.vertices[0]);
	        area= Math.abs(sum)/2;
	       
	    }
	    //getters and setters
	    public double get_area()
	    {
	    	return area;
	    }
	//using Percatge Difference formula to find which polygon is bigger
		public boolean ComesBefore(Polygon data) {
			 double numerator,denominator,Percentage;
			 numerator= (Math.abs(data.get_area() - this.get_area()));
		     denominator = (data.get_area() + this.get_area() / 2); 
		     Percentage = (numerator / denominator) * 100;
		        if(Percentage > 0.1 && this.get_area() < data.get_area())//check if perctage is bigger then 0.1% of smaller polygon
		        { 
		            return true; 
		        }
		        else {//percentage is less 0.1% then check distance from origin if its less then return true else false
		            if(this.distance_from_origin()<data.distance_from_origin())
		            { 
		                return true; 
		            }
		        }
			return false;
		}
		
		
}

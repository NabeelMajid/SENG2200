/* Name: Nabeel Majid(C3287060)
 * Seng2200-Assignment2
 * Date: 15-04-23
description: abstract planarShape class with 3 abstract method and one concreate method its a parent class for 
Circle,Polygon and Semicircle. 
*/
public abstract class PlanarShape implements Comparable<PlanarShape>{
	
public abstract String toString();
public abstract double area();
public abstract double distance_from_origin();
//
@Override
public int CompareTo(PlanarShape shape) {
	 double numerator,denominator,Percentage;
	 numerator= (Math.abs(shape.area() - this.area()));
    denominator = (shape.area() + this.area() / 2); 
    Percentage = (numerator / denominator) * 100;
       if( this.area() < shape.area())//check if area is smaller 
       {
    	   if(Percentage > 0.05 )//check if perctage is bigger then 0.5% of smaller polygon
       {
    	   //System.out.print(this.area()+"  < " +shape.area()+"\n");
           return 1; 
       }
    	   else if(Percentage<0.05)//if percentage is smaller
    	   {
    		   if(this.distance_from_origin()<shape.distance_from_origin())//to check distance of origin is smaller 
               { 
                   return 1; 
               }
    	   }
    	   else//if they are equal
    	   {
    		   return 0;
    	   }
       }
      
       
	return -1;
}
}

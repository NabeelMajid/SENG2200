
public class Circle extends PlanarShape {
	private Point centre;
	private double radius;
	//default constructor
	public Circle()
	{
		centre=null;
		radius=0;
		
	}
	
	//Circle constructor with double array as a parameter
	public Circle(double[] arr)
	{
		
		centre = new Point();
		centre.set_X(arr[0]);
		centre.set_Y(arr[1]);
		radius= arr[2];
		
	}
	//method to print a Circle
	@Override
	public String toString() {
		    
		return "CIRC=[" + centre.toString() +   radius+ "]:  "+  String.format("%5.2f" , this.area());
	}
//method to calculate area and return it
	@Override
	public double area() {
		double area;
		
		 area= Math.PI*radius*radius;
		return area;
	}
	
//method to find distance of origin
	@Override
	public double distance_from_origin() {
		double distance;
		distance= centre.get_distance()-radius;
		return distance;
	}

}

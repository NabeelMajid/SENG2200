/* Name: Nabeel Majid(C3287060)
 * Seng2200-Assignment2
 * Date 15/04/23
description: Generic Node class to for Linkedlist and Have generic Next and pervious as well as Data to be stores.
*/
public class Node<T> {
	private T data;
	private Node<T> next;
	private Node<T> previous;
	//constructor
	public Node()
	{
		data=null;
		next=null;
		previous=null;
		
	}
	public Node(T _data)//constructor with one parameter
	{
		data=_data;
		next=null;
		previous=null;
	}
	//setter and getters
	public Node<T> getNext()
	{
		return next;
	}
	public Node<T> getPrevious()
	{
		return previous;
	}
	public T getData()
	{
		return data;
	}
	public void setNext(Node<T> temp)
	{
		next=temp;
	}
	public void setPrev (Node<T> temp)
	{
		previous = temp;
	}
	public void setData(T _data)
	{
		data=_data;
	}
	
}

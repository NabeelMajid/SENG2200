
public class MyPolygon {
	private Node Sentinel;
	private Node current;
	//constructor to create linkedlist of MyPolygon type
	public MyPolygon()
	{
		Sentinel = new Node(null);
		current=Sentinel;
		Sentinel.setNext(Sentinel);
		Sentinel.setPrev(Sentinel);
		
	}
	//To add data at the head of linkedlist
	public void prepend(Polygon data)
	
	{
		Node temp= new Node(data);
		reset();// move current to the first node after sentinel
		temp.setNext(current);
		temp.setPrev(Sentinel);
		current.setPrev(temp);
		Sentinel.setNext(temp);
		
	}
	//To add data at the end of linkedlist
	public void append(Polygon data)
	{
		Node temp = new Node(data);
		temp.setNext(Sentinel);
		temp.setPrev(Sentinel.getPrevious());
		Sentinel.getPrevious().setNext(temp);
		Sentinel.setPrev(temp);
		
	}
	//move current to the next node
	   public void Next()
	    {
	        current=current.getNext();
	    }
	   //move current to the first node
	    public void reset()
	    {
	        current=Sentinel.getNext();
	    }
	    //this method takes 1 parameter of Polygon type and then insert it into linkedlist in ascending order
	    //also uses comesbefore method in polygon.
	    public void InsertinOrder(Polygon data)
	    {
	    	boolean inserted= false;
		 	if (Sentinel.getNext()== Sentinel)//checking if Linkedlist is empty then add at head
		 	{
		 		prepend(data);
		 	}
		 	else
		 	{
		 		reset();
		 		while(current!=Sentinel)//checking till the end of linkedlist
		 		{
		 		if(	data.ComesBefore(current.getData()))
		 		{
		 			
		 			Insert(data);
		 			inserted= true;//checking if any data in linkedlist is bigger then insert it
		 			break;
		 		}
		 		Next();
		 		}
	    	if(inserted==false)// if the data is not smaller then any data then add at the end
	    	{
	    		append(data);
	    	}
		 	}
	    }
	    //Method to add data before current pointer
	    public void Insert(Polygon data)
	    {
	    	if (current.getNext()==Sentinel)
	    	{
	    		append(data);
	    		
	    	}
	    	else
	    	{
	    		Node temp= new Node(data);
	    		temp.setPrev(current.getPrevious());
	    		temp.setNext(current);
	    		current.getPrevious().setNext(temp);
	    		current.setPrev(temp);
	    		
	    	
	    	}
	    }
	    //take will remove data from the list
	    public Polygon take()
	    {
	    	Node temp= new Node();
	    	temp=Sentinel.getNext();
	    	if(Sentinel.getNext()==Sentinel)
	    	{
	    	System.out.print("list is empty");	
	    	}
	    	else
	    	{
	    		Next();
	    		Sentinel.setNext(current);
	    		current.setPrev(Sentinel);
	    		
	    	}
	    return temp.getData();	
	    }
	    
	 //To convert Linkedlist to string
	    public String toString()
		{
			String result="";
			reset();
			while(current!=Sentinel)
			{
				result+=current.getData().toString()+"\n";
				Next();
			}
			return result;
		}
	    
}

/* Name: Nabeel Majid(C3287060)
 * Seng2200-Assignment2
 * Date 26/04/23
description: abstract planarShape class with 3 abstract method and one concreate method its a parent class for 
Circle,Polygon and Semicircle. 
*/
public class SortedLinkedList<T extends PlanarShape> extends LinkedList<T>{

    // constructor
    public SortedLinkedList(){
        Sentinel= new Node<T>();
        Sentinel.setNext(Sentinel);
        Sentinel.setPrev(Sentinel);
    }

    @Override
    public void Insert(T data){
        InsertinOrder(data);
    }

    @Override
    public void append(T data){
        throw new UnsupportedOperationException("Invalid method for sorted LinkedList");
    }

    @Override
    public void prepend(T data){
        throw new UnsupportedOperationException("Invalid method for sorted LinkedList");
    }
    
    
    
    
    public void InsertinOrder(T data){
        Node<T> temp = new Node<T>(data);
        Node<T> current = this.Sentinel.getNext();
        if(/*this.size==0*/current==Sentinel){
            temp.setPrev(this.Sentinel);
            temp.setNext(this.Sentinel);
            this.Sentinel.setNext(temp);
            this.Sentinel.setPrev(temp);
            
        }
        else {
            while (current != this.Sentinel) {
                if (temp.getData().CompareTo(current.getData()) <= 0) {
                    temp.setNext(current);
                    temp.setPrev(current.getPrevious());
                    current.getPrevious().setNext(temp);
                    current.setPrev(temp);
                    
                    break;
                }

                current = current.getNext();
            }
            if (current == this.Sentinel) {
                temp.setPrev(this.Sentinel.getPrevious());
                temp.setNext(this.Sentinel);
                this.Sentinel.getPrevious().setNext(temp);
                this.Sentinel.setPrev(temp);
                
            }
        }
    }

   
}



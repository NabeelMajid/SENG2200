import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.FileWriter;
public class A1 {
	   
	   
	    
	     public static void main(String[] args) throws FileNotFoundException, IOException
	     
	     {
		   			MyPolygon list = new MyPolygon();
		   			MyPolygon Sortedlist = new MyPolygon();
		   			Polygon polygon=new Polygon();
	    	 		Point[] points ;
	                int n;
	               
	             
	               
		            // Scanner  inputStream = new Scanner(new File("sample_in.txt"));
		           
	             Scanner  inputStream = new Scanner(new File(args[0]));
	              //to open a file and takes argument as name for file
	           
	              
	               
					while(inputStream.hasNext())//reading from file and storing it in point object
	                {
	                	
	                    String word = inputStream.next();//reading by line
	                                     
	                    
	                     
	                        if(word.charAt(0)=='P')//checking P in file
	                        {
	                                            
	                            n = inputStream.nextInt();//to get the size of Polygon
	                            points =new Point[n];
	                           for(int i=0;i<n;i++)//initializing point and storing it in point array
	                           {
	                        	   points[i]=new Point();
	                        	   points[i].set_X(inputStream.nextDouble());
	                               points[i].set_Y(inputStream.nextDouble());		
	                              
	                           }
	                           
	                        polygon = new Polygon(points);//Polygon with point type 
	                        polygon.Cal_area(n);//Calculating area of polygon
	                        list.append(polygon);
	                        Sortedlist.InsertinOrder(polygon);
	                        
	                        
	                        }
	                        
	                }     
	         File f=new File("sample_out.txt");
	         FileWriter fw= new FileWriter(f);
	         fw.write(list.toString()+"\n"+"----------------------------------------------------------------\n");
	         fw.write(Sortedlist.toString());
	         
	         
	         fw.close();
	         
	         
	         }//main function

}
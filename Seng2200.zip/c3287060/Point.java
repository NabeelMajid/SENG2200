/* Name: Nabeel Majid(C3287060)
 * Seng2200-Assignment2
 description: This class store X and Y axis value in double form.
*/

public class Point {
	private double x;
	private double y;
	double distance;
	//constructor
	public Point()
	{
	x=0;
	y=0;
	}
	//constructor with two parameter
	public Point(double a, double b)
	{
	x=a;
	y=b;
	}
	//getters and setter
	public double get_X()
	{
	return x;	
	}
	public double get_Y()
	{
	return y;	
	}
	public double get_distance()
	{
	return distance;	
	}
	
	
	public void set_X(double temp)
	{
	x=temp;	
	}
	public void set_Y(double temp)
	{
	y=temp;
	}
	public void set_distance(double temp)
	{
	distance = temp;	
	}
	//distance to origin and to string
	
	//method to calculate the distance of a point in a polygon from origin;
	 public void distance_from_origin()
	    {
	     distance = Math.sqrt(Math.pow(x,2)+Math.pow(y,2));
	    }
	 //method to convert it to string
	 public String toString()
	 {
		 return "(" + String.format("%3.2f", x) + "," + String.format("%3.2f", y) + ")"; 
	 }
}

/* Name: Nabeel Majid(C3287060)
 * Seng2200-Assignment2
 * Date 15/04/23
*/
public interface Comparable<PlanarShape> { 
int CompareTo(PlanarShape o); // true if this < param 
} 

public class Node {
	private Polygon data;
	private Node next;
	private Node previous;
	//constructor
	public Node()
	{
		data=null;
		next=null;
		previous=null;
		
	}
	public Node(Polygon _data)//constructor with one parameter
	{
		data=_data;
		next=null;
		previous=null;
	}
	//setter and getters
	public Node getNext()
	{
		return next;
	}
	public Node getPrevious()
	{
		return previous;
	}
	public Polygon getData()
	{
		return data;
	}
	public void setNext(Node temp)
	{
		next=temp;
	}
	public void setPrev (Node temp)
	{
		previous = temp;
	}
	public void setData(Polygon _data)
	{
		data=_data;
	}
	
}

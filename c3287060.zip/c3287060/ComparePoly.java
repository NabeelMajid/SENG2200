public interface ComparePoly { 
boolean ComesBefore(Polygon o); // true if this < param 
} 
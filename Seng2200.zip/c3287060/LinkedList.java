/* Name: Nabeel Majid(C3287060)
 * Seng2200-Assignment2
 * Date 22/04/23
description: LinkedList class to store all the planarShape Data and also have Iterator to traverse through the data 
of Linkedlist 
*/
import java.util.Iterator;
import java.lang.UnsupportedOperationException;
import java.util.NoSuchElementException;

public class LinkedList<T extends PlanarShape> implements Iterable<T> {

	protected Node<T>Sentinel;
	protected int size;
	//constructor to create linkedlist of MyPolygon type
	public LinkedList()
	{
		Sentinel = new Node<T>(null);
		Sentinel.setNext(Sentinel);
		Sentinel.setPrev(Sentinel);
		size=0;	
	}
	//To add data at the head of linkedlist
	public void prepend(T data)
	
	{
		Node<T>temp= new Node<T>(data);
		temp.setNext(Sentinel.getNext());
		temp.setPrev(Sentinel);
		Sentinel.getNext().setPrev(temp);
		Sentinel.setNext(temp);
		size++;
		
	}
	//To add data at the end of linkedlist
	public void append(T data)
	{
		Node<T> temp = new Node<T>(data);
		temp.setNext(Sentinel);
		temp.setPrev(Sentinel.getPrevious());
		Sentinel.getPrevious().setNext(temp);
		Sentinel.setPrev(temp);
		size++;
	}
	//move current to the next node
	   public void Next()
	    {
	        //current=current.getNext();
		   throw new UnsupportedOperationException("LinkedList.Next(): Invalid method");
	    }
	   //move current to the first node
	    public void reset()
	    {
	    	throw new UnsupportedOperationException("LinkedList.Next(): Invalid method");
	    }
	    //Method to add data before current pointer
	    public void Insert(T data)
	    {
	    	append(data);
	    }
	    //take will remove data from the list
	    public T take() throws Exception
	    {
	    	T data ;
	    	Node<T> temp= new Node<T>();
	    	temp=Sentinel.getNext();
	    	if(Sentinel.getNext()==Sentinel)
	    	{
	    	throw new Exception("Empty List: No item to remove");	
	    	}
	    	else
	    	{
	    		data = Sentinel.getNext().getData();
	    		temp.getNext().setPrev(Sentinel);
	    		Sentinel.setNext(temp.getNext());
	    		
	    	}
	    return  data;	
	    }
	//constructor for Iterator
	@Override
	public Iterator<T> iterator() {
		// TODO Auto-generated method stub
		return new LinkedListIterator();
	}
	private class LinkedListIterator implements Iterator<T> {
		private Node<T> current = Sentinel;
	    
	      
	    // iterator method to read till the end and check if there is element then return true else false
	    public boolean hasNext()
	    {
	        if(current.getNext()==Sentinel)
	        {
			return false;
	        }
	        else
	        {
	        	return true;
	        }
	    }
	    
	    // method to move to next and return data
	    public T next() {
	        if (!hasNext())
	        	{
	        	throw new NoSuchElementException();
	        	}
	        current=current.getNext();
	        return current.getData();
	    }

	}
	
}
 
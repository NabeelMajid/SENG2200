/* Name: Nabeel Majid(C3287060)
 * Seng2200-Assignment2
 * Date 15/04/23
*/
public class Polygon extends PlanarShape{//Polygon class implement Comesbefore method
	private Point [] vertices ;
	private  double area;
	private double origin;
	//polygon default construct
	public Polygon()
	{
		area = 0;
		origin= 0;
		vertices=null; 
		
	}
	//polygon constructor with Point array
	public Polygon(Point[] p)
	{
		
		vertices = new Point[p.length];
		for(int i=0; i<p.length;i++)
		{
			vertices[i]=new Point();
			vertices[i]=p[i];
			vertices[i].distance_from_origin();
		}
	
		
	}
	//method to find the nearest point from origin by comparing all the point in the polygon and storing it in origin
	public double distance_from_origin()
	{
		origin= vertices[0].get_distance();
		for(int i=1; i<vertices.length;i++)
		{
			if(origin>vertices[i].get_distance())
			{
				origin=vertices[i].get_distance();
			}
		}
		return origin;
	}
	//Method to convert Polygon into string of format 6.2
	public String toString()
    {
                
        String str = "Poly= [";
        if(vertices != null)
        {
            for(int x = 0; x < vertices.length; x++)
            {
                str += "("+vertices[x].toString()+") ";               
            }
        }
        else{
            str = null;
        }
        
        return str+"]:   "+String.format("%5.2f" , this.area());
    }
	// this method calculate the product of P1 and Point two to find area
	 public double c_prod(Point p1, Point p2)
	   {
	       return (p1.get_X() * p2.get_Y())-(p1.get_Y()*p2.get_X());
	    }
	   //method to calculate area of Polygon 
	    public double area()
	    {
	     int n=this.vertices.length; 
	    	double sum=0;
	        for(int i=0;i<n-1;i++)
	        {
	        sum+=c_prod(this.vertices[i],this.vertices[i+1]);
	        
	        }
	        sum+=c_prod(this.vertices[n-1],this.vertices[0]);
	        area= Math.abs(sum)/2;
	        return area;
	       
	    }
	  
		
		
		
	
		}
		
		

